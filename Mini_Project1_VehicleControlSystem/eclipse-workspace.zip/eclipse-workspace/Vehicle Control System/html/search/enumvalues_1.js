var searchData=
[
  ['off_56',['OFF',['../prototypes_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8aac132f2982b98bcaa3445e535a03ff75',1,'prototypes.h']]],
  ['orange_57',['ORANGE',['../prototypes_8h.html#ad358054530f05e2055e439d04f7c293bace9ee4c1a6b777940c7f3a766a9a88d4',1,'prototypes.h']]]
];
