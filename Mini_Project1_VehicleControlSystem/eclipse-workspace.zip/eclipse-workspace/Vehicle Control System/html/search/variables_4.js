var searchData=
[
  ['roomtemp_47',['roomTemp',['../structSystemState.html#a17bee535ad0a516b369e01481ab35099',1,'SystemState']]]
];
