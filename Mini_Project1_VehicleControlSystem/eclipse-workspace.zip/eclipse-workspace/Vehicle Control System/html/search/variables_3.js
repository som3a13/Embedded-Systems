var searchData=
[
  ['ptr_46',['ptr',['../main_8c.html#a075c3aeac1775376460bce6c5376bfc3',1,'main.c']]]
];
