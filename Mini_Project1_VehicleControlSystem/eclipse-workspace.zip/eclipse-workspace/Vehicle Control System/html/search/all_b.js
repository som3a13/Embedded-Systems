var searchData=
[
  ['userinput_27',['userInput',['../structSystemState.html#af2b70cd8aa393fb767fc4b84cd43ee79',1,'SystemState']]]
];
