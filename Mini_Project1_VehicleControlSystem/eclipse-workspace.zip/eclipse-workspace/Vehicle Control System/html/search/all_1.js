var searchData=
[
  ['color_1',['color',['../structSystemState.html#a8ae8f80039f0d4748f459295d202b064',1,'SystemState']]]
];
