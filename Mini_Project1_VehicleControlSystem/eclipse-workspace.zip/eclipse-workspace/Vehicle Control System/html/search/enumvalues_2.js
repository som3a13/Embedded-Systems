var searchData=
[
  ['red_58',['RED',['../prototypes_8h.html#ad358054530f05e2055e439d04f7c293baf80f9a890089d211842d59625e561f88',1,'prototypes.h']]],
  ['running_59',['RUNNING',['../prototypes_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a1061be6c3fb88d32829cba6f6b2be304',1,'prototypes.h']]]
];
