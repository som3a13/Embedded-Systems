var searchData=
[
  ['green_55',['GREEN',['../prototypes_8h.html#ad358054530f05e2055e439d04f7c293baa60bd322f93178d68184e30e162571ca',1,'prototypes.h']]]
];
