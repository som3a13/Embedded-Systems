var searchData=
[
  ['sensorsinput_48',['sensorsInput',['../structSystemState.html#a016c408f0f452efc5d5d74f1f49f702f',1,'SystemState']]],
  ['systemstate_49',['systemState',['../main_8c.html#ac705089b22877f6322d09a9f0f5bdb1d',1,'main.c']]]
];
