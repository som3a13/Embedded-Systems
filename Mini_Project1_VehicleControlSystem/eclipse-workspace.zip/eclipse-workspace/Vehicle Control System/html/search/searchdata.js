var indexSectionsWithContent =
{
  0: "acefgmoprstuvw",
  1: "s",
  2: "mp",
  3: "ms",
  4: "aceprsuv",
  5: "f",
  6: "st",
  7: "gor",
  8: "w"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

