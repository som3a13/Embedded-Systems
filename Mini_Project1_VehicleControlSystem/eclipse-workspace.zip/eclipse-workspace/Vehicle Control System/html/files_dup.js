var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "prototypes.h", "prototypes_8h.html", "prototypes_8h" ]
];