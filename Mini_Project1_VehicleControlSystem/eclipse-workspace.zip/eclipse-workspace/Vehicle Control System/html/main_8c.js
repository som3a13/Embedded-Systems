var main_8c =
[
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "mainMenu", "main_8c.html#ab3002fe8e0074c9e2ecb5b835e5e819f", null ],
    [ "sensorsMenu", "main_8c.html#a32371c9d181667ed4468527479b200b6", null ],
    [ "sensorsVal", "main_8c.html#ac40dbc90d8db9b5e32b6862dda69fee4", null ],
    [ "setTemp_AC", "main_8c.html#a6f04bc68a4def1d7b022a02dfa844457", null ],
    [ "setTemp_EC", "main_8c.html#a04ce8ce8148209d4f10241da04cd6edc", null ],
    [ "setTraffic", "main_8c.html#a2899e6add29016990141654e259d3b2d", null ],
    [ "speedControl", "main_8c.html#a439d8d8270a47e1fde0102011196e7b1", null ],
    [ "stateAction", "main_8c.html#a11c9a3323292418091435cb4ddfd0165", null ],
    [ "ptr", "main_8c.html#a075c3aeac1775376460bce6c5376bfc3", null ],
    [ "systemState", "main_8c.html#ac705089b22877f6322d09a9f0f5bdb1d", null ]
];