var structSystemState =
[
    [ "AC_State", "structSystemState.html#a2c430c8fe493c0733600fc32c631ac68", null ],
    [ "color", "structSystemState.html#a8ae8f80039f0d4748f459295d202b064", null ],
    [ "EC_State", "structSystemState.html#a75f683334674149aa03022cc020a68a2", null ],
    [ "engineTemp", "structSystemState.html#a799ba02f1770b3fc5233e23d3f174ac2", null ],
    [ "roomTemp", "structSystemState.html#a17bee535ad0a516b369e01481ab35099", null ],
    [ "sensorsInput", "structSystemState.html#a016c408f0f452efc5d5d74f1f49f702f", null ],
    [ "userInput", "structSystemState.html#af2b70cd8aa393fb767fc4b84cd43ee79", null ],
    [ "vehicleState", "structSystemState.html#a7e515c138d99a7e06d3e0fb852e75893", null ]
];