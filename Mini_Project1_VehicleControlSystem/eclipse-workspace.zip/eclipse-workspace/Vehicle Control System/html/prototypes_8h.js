var prototypes_8h =
[
    [ "SystemState", "structSystemState.html", "structSystemState" ],
    [ "WITH_ENGINE_TEMP_CONTROLLER", "prototypes_8h.html#a88d9579a814f200ce1c938dfe68fa939", null ],
    [ "funPTR", "prototypes_8h.html#a0b60215233d35716c5a905731fc8ceec", null ],
    [ "State", "prototypes_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8", [
      [ "OFF", "prototypes_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8aac132f2982b98bcaa3445e535a03ff75", null ],
      [ "RUNNING", "prototypes_8h.html#a5d74787dedbc4e11c1ab15bf487e61f8a1061be6c3fb88d32829cba6f6b2be304", null ]
    ] ],
    [ "Traffic", "prototypes_8h.html#ad358054530f05e2055e439d04f7c293b", [
      [ "RED", "prototypes_8h.html#ad358054530f05e2055e439d04f7c293baf80f9a890089d211842d59625e561f88", null ],
      [ "ORANGE", "prototypes_8h.html#ad358054530f05e2055e439d04f7c293bace9ee4c1a6b777940c7f3a766a9a88d4", null ],
      [ "GREEN", "prototypes_8h.html#ad358054530f05e2055e439d04f7c293baa60bd322f93178d68184e30e162571ca", null ]
    ] ],
    [ "mainMenu", "prototypes_8h.html#ab3002fe8e0074c9e2ecb5b835e5e819f", null ],
    [ "sensorsMenu", "prototypes_8h.html#a32371c9d181667ed4468527479b200b6", null ],
    [ "sensorsVal", "prototypes_8h.html#ac40dbc90d8db9b5e32b6862dda69fee4", null ],
    [ "setTemp_AC", "prototypes_8h.html#a6f04bc68a4def1d7b022a02dfa844457", null ],
    [ "setTemp_EC", "prototypes_8h.html#a04ce8ce8148209d4f10241da04cd6edc", null ],
    [ "setTraffic", "prototypes_8h.html#a2899e6add29016990141654e259d3b2d", null ],
    [ "speedControl", "prototypes_8h.html#a439d8d8270a47e1fde0102011196e7b1", null ],
    [ "stateAction", "prototypes_8h.html#a11c9a3323292418091435cb4ddfd0165", null ]
];